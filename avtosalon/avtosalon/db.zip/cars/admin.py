from django.contrib import admin
from .models import Brend, Car

admin.site.register(Brend)
admin.site.register(Car)

